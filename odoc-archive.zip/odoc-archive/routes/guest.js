const express = require("express");
const router = express.Router();
const store = require("../data/store");

// Landing / Home
router.get("/", (req, res) => {
  const { filter } = req.query;
  let list = store.activities;
  if (filter === "ongoing") list = list.filter((a) => a.status === "Ongoing");
  if (filter === "upcoming") list = list.filter((a) => a.status === "Upcoming");

  res.render("home", {
    title: "ODOC Digital Archive",
    layout: "layouts/guest",
    activities: list,
    activeFilter: filter || "all"
  });
});

// Activity detail (public)
router.get("/activity/:id", (req, res) => {
  const activity = store.findActivity(req.params.id);
  if (!activity) {
    return res.status(404).render("404", { layout: "layouts/guest", title: "Activity Not Found" });
  }
  res.render("activity-detail", {
    title: activity.title,
    layout: "layouts/guest",
    activity
  });
});

module.exports = router;
